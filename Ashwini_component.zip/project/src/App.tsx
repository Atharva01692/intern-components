import React from 'react';
import SkillProgressDashboard from './components/SkillProgressDashboard';

function App() {
  return <SkillProgressDashboard />;
}

export default App;