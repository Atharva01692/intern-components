document.addEventListener('DOMContentLoaded', function() {

    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const part2 = document.getElementById('part2');
    
    mobileMenuBtn.addEventListener('click', function() {
        part2.classList.toggle('active');
    });
    
    const tl = gsap.timeline();
    
    tl.from("#nav h2", {
        y: -20,
        duration: 1,
        opacity: 0,
        ease: "power3.out"
    });
    
    tl.from("#part2 h4", {
        y: -20,
        duration: 0.8,
        opacity: 0,
        stagger: 0.2,
        ease: "back.out(1.7)"
    }, "-=0.5");
    
    tl.from("#main-heading", {
        y: 50,
        opacity: 0,
        duration: 1,
        scale: 0.8,
        ease: "elastic.out(1, 0.5)"
    }, "-=0.5");
    
    tl.to("#sub-text", {
        opacity: 1,
        duration: 1,
        ease: "power2.out"
    });
    
    tl.from("#animated-circle", {
        scale: 0,
        opacity: 0,
        duration: 1.5,
        ease: "power3.out"
    }, "-=1");
    
    gsap.to("#animated-circle", {
        rotation: 360,
        duration: 30,
        repeat: -1,
        ease: "none"
    });
    
    document.getElementById('main-heading').addEventListener('mouseenter', function() {
        gsap.to(this, {
            scale: 1.05,
            duration: 0.3,
            color: "#ff6b6b",
            ease: "power2.out"
        });
    });
    
    document.getElementById('main-heading').addEventListener('mouseleave', function() {
        gsap.to(this, {
            scale: 1,
            duration: 0.3,
            color: "#ffffff",
            ease: "power2.out"
        });
    });
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            gsap.to("#nav", {
                backgroundColor: "rgba(0, 0, 0, 0.8)",
                padding: "15px 50px",
                duration: 0.3
            });
        } else {
            gsap.to("#nav", {
                backgroundColor: "#000000",
                padding: "30px 50px",
                duration: 0.3
            });
        }
    });
});