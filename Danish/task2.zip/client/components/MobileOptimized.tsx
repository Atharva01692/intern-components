import React from "react";
import { motion } from "framer-motion";

interface MobileOptimizedProps {
  children: React.ReactNode;
}

export const MobileOptimized: React.FC<MobileOptimizedProps> = ({
  children,
}) => {
  return (
    <div className="relative">
      <div className="md:hidden">
        <style jsx>{`
          @media (max-width: 768px) {
            .particle-reduced {
              display: none;
            }
            .animation-reduced {
              animation-duration: 6s !important;
            }
          }
        `}</style>
      </div>

      <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 md:hidden">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2, duration: 1 }}
          className="bg-white/10 backdrop-blur-lg rounded-full px-4 py-2 border border-white/20"
        >
          <p className="text-white/80 text-sm">Tap to explore</p>
        </motion.div>
      </div>

      {children}
    </div>
  );
};
