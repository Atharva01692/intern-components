import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MobileOptimized } from "./MobileOptimized";

interface Particle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
}

export const InteractivePortal: React.FC = () => {
  const [activePanel, setActivePanel] = useState(0);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [particles, setParticles] = useState<Particle[]>([]);
  const [trailPoints, setTrailPoints] = useState<
    Array<{ x: number; y: number; timestamp: number }>
  >([]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  const panels = [
    {
      title: "Creative Vision",
      subtitle: "Where imagination meets innovation",
      description:
        "Transforming abstract ideas into captivating digital experiences through cutting-edge design principles and interactive storytelling.",
      color: "aurora",
      accent: "from-purple-500 to-pink-500",
    },
    {
      title: "Dynamic Flow",
      subtitle: "Motion that speaks volumes",
      description:
        "Crafting seamless animations and micro-interactions that guide users through intuitive journeys with purposeful movement.",
      color: "cyber",
      accent: "from-cyan-500 to-blue-500",
    },
    {
      title: "Luminous Energy",
      subtitle: "Illuminating digital landscapes",
      description:
        "Harnessing the power of color, light, and form to create memorable experiences that resonate with users on an emotional level.",
      color: "plasma",
      accent: "from-orange-500 to-red-500",
    },
  ];

  useEffect(() => {
    const initParticles = () => {
      const newParticles: Particle[] = [];
      const particleCount = window.innerWidth < 768 ? 20 : 50;
      for (let i = 0; i < particleCount; i++) {
        newParticles.push({
          id: i,
          x: Math.random() * window.innerWidth,
          y: Math.random() * window.innerHeight,
          vx: (Math.random() - 0.5) * 2,
          vy: (Math.random() - 0.5) * 2,
          size: Math.random() * 3 + 1,
          color: `hsla(${Math.random() * 360}, 70%, 60%, 0.6)`,
          life: Math.random() * 100 + 50,
        });
      }
      setParticles(newParticles);
    };

    initParticles();
  }, []);

  useEffect(() => {
    const animateParticles = () => {
      setParticles((prev) =>
        prev
          .map((particle) => {
            let newX = particle.x + particle.vx;
            let newY = particle.y + particle.vy;

            if (newX <= 0 || newX >= window.innerWidth) particle.vx *= -1;
            if (newY <= 0 || newY >= window.innerHeight) particle.vy *= -1;

            const dx = mousePosition.x - newX;
            const dy = mousePosition.y - newY;
            const distance = Math.sqrt(dx * dx + dy * dy);

            if (distance < 100) {
              const force = (100 - distance) / 100;
              newX -= dx * force * 0.03;
              newY -= dy * force * 0.03;
            }

            return {
              ...particle,
              x: Math.max(0, Math.min(window.innerWidth, newX)),
              y: Math.max(0, Math.min(window.innerHeight, newY)),
              life: particle.life - 0.5,
            };
          })
          .filter((particle) => particle.life > 0),
      );
    };

    const animate = () => {
      animateParticles();
      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [mousePosition]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const newPosition = { x: e.clientX, y: e.clientY };
      setMousePosition(newPosition);

      setTrailPoints((prev) => {
        const newTrail = [...prev, { ...newPosition, timestamp: Date.now() }];
        return newTrail
          .filter((point) => Date.now() - point.timestamp < 1000)
          .slice(-15);
      });
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActivePanel((prev) => (prev + 1) % panels.length);
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  const currentPanel = panels[activePanel];

  return (
    <MobileOptimized>
      <div className="relative min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-800/20 via-cyan-800/20 to-orange-800/20 animate-gradient-shift"></div>
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-purple-500/30 to-pink-500/30 rounded-full blur-3xl animate-morph"></div>
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gradient-to-r from-cyan-500/30 to-blue-500/30 rounded-full blur-3xl animate-float"></div>
          <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-gradient-to-r from-orange-500/30 to-red-500/30 rounded-full blur-3xl animate-pulse-slow"></div>
        </div>

        <div className="absolute inset-0 pointer-events-none">
          {particles.map((particle) => (
            <div
              key={particle.id}
              className="absolute w-1 h-1 rounded-full animate-particle-float"
              style={{
                left: particle.x,
                top: particle.y,
                backgroundColor: particle.color,
                width: particle.size,
                height: particle.size,
                opacity: particle.life / 100,
              }}
            />
          ))}
        </div>

        <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-8">
          <motion.div
            className="text-center max-w-4xl mx-auto"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            <motion.h1
              className="text-4xl sm:text-6xl md:text-8xl font-bold mb-6 md:mb-8 tracking-tight px-4"
              style={{
                background: `linear-gradient(135deg, ${currentPanel.accent})`,
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                color: "transparent",
              }}
              key={activePanel}
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -50, opacity: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              NEXUS
            </motion.h1>

            <div className="flex justify-center space-x-4 mb-12">
              {panels.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActivePanel(index)}
                  className={`w-4 h-4 rounded-full transition-all duration-500 ${
                    index === activePanel
                      ? "bg-white scale-125 shadow-lg shadow-white/50"
                      : "bg-white/30 hover:bg-white/50"
                  }`}
                />
              ))}
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={activePanel}
                initial={{ opacity: 0, y: 30, rotateX: -15 }}
                animate={{ opacity: 1, y: 0, rotateX: 0 }}
                exit={{ opacity: 0, y: -30, rotateX: 15 }}
                transition={{ duration: 0.6, ease: "easeOut" }}
                className="bg-white/10 backdrop-blur-lg rounded-2xl md:rounded-3xl p-6 md:p-12 border border-white/20 shadow-2xl mx-4 md:mx-0"
              >
                <h2 className="text-2xl sm:text-4xl md:text-5xl font-bold text-white mb-3 md:mb-4">
                  {currentPanel.title}
                </h2>
                <p className="text-lg sm:text-xl text-white/80 mb-4 md:mb-6 font-light">
                  {currentPanel.subtitle}
                </p>
                <p className="text-base sm:text-lg text-white/70 leading-relaxed max-w-2xl mx-auto">
                  {currentPanel.description}
                </p>

                <div className="flex justify-center items-center space-x-12 mt-12">
                  <motion.div
                    whileHover={{
                      scale: 1.2,
                      rotateY: 180,
                      rotateX: 15,
                    }}
                    whileTap={{
                      scale: 0.9,
                      rotateZ: 45,
                    }}
                    className="relative w-24 h-24 cursor-pointer group perspective-1000"
                    style={{
                      transformStyle: "preserve-3d",
                      perspective: "1000px",
                    }}
                  >
                    <div className="absolute inset-0 rounded-lg bg-gradient-to-br from-purple-400/60 via-pink-500/60 to-violet-600/60 backdrop-blur-sm border border-white/30 group-hover:border-white/60 transition-all duration-500 shadow-2xl">
                      <div className="absolute inset-2 rounded-md bg-gradient-to-tr from-white/20 to-transparent" />
                      <div className="absolute inset-0 rounded-lg overflow-hidden">
                        <div className="absolute top-2 left-2 w-3 h-3 bg-white/70 rounded-full animate-pulse" />
                        <div className="absolute bottom-2 right-2 w-2 h-2 bg-cyan-300/80 rounded-full animate-ping" />
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                          <div
                            className="w-8 h-8 border-2 border-white/60 rounded-full animate-spin"
                            style={{ animationDuration: "3s" }}
                          >
                            <div className="absolute top-1 left-1 w-2 h-2 bg-white rounded-full" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>

                  <motion.div
                    whileHover={{
                      scale: 1.15,
                      rotateY: -20,
                      rotateX: 20,
                      z: 50,
                    }}
                    whileTap={{
                      scale: 0.85,
                      rotateZ: -30,
                    }}
                    className="relative cursor-pointer group"
                    style={{
                      transformStyle: "preserve-3d",
                    }}
                  >
                    <div className="relative w-28 h-28">
                      <div
                        className="absolute inset-0 bg-gradient-to-r from-cyan-400/50 via-blue-500/50 to-indigo-600/50 backdrop-blur-sm border border-white/30 group-hover:border-white/60 transition-all duration-500 shadow-2xl"
                        style={{
                          clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)",
                          transform: "rotateX(0deg)",
                        }}
                      />
                      <div
                        className="absolute inset-0 bg-gradient-to-l from-blue-300/30 to-transparent"
                        style={{
                          clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)",
                        }}
                      />
                      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 mt-4">
                        <div className="flex space-x-1">
                          <div
                            className="w-1 h-6 bg-white/60 animate-pulse"
                            style={{ animationDelay: "0s" }}
                          />
                          <div
                            className="w-1 h-4 bg-white/60 animate-pulse"
                            style={{ animationDelay: "0.2s" }}
                          />
                          <div
                            className="w-1 h-8 bg-white/60 animate-pulse"
                            style={{ animationDelay: "0.4s" }}
                          />
                          <div
                            className="w-1 h-3 bg-white/60 animate-pulse"
                            style={{ animationDelay: "0.6s" }}
                          />
                        </div>
                      </div>
                    </div>
                  </motion.div>

                  <motion.div
                    whileHover={{
                      scale: 1.25,
                      rotateY: 360,
                      rotateX: -10,
                    }}
                    whileTap={{
                      scale: 0.8,
                      rotateZ: 90,
                    }}
                    className="relative cursor-pointer group"
                    style={{
                      transformStyle: "preserve-3d",
                    }}
                  >
                    <div className="relative w-20 h-20">
                      <div className="absolute inset-0 bg-gradient-to-br from-orange-400/60 via-red-500/60 to-pink-600/60 backdrop-blur-sm border border-white/30 group-hover:border-white/60 transition-all duration-700 shadow-2xl transform rotate-45">
                        <div className="absolute inset-1 bg-gradient-to-tl from-white/30 to-transparent transform -rotate-45" />
                      </div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="relative">
                          {[...Array(6)].map((_, i) => (
                            <div
                              key={i}
                              className="absolute w-1 h-1 bg-white/70 rounded-full"
                              style={{
                                transform: `rotate(${i * 60}deg) translateY(-8px)`,
                                transformOrigin: "center 8px",
                                animationDelay: `${i * 0.1}s`,
                              }}
                            />
                          ))}
                          <div className="w-3 h-3 bg-gradient-to-r from-yellow-300 to-orange-300 rounded-full animate-pulse" />
                        </div>
                      </div>
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            </AnimatePresence>

            <motion.div
              className="mt-16 text-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1, duration: 1 }}
            >
              <div className="inline-flex items-center space-x-2 text-white/60 text-sm uppercase tracking-widest">
                <div className="w-8 h-px bg-gradient-to-r from-transparent to-white/40"></div>
                <span>Interactive Experience</span>
                <div className="w-8 h-px bg-gradient-to-r from-white/40 to-transparent"></div>
              </div>
            </motion.div>
          </motion.div>
        </div>

        <div className="fixed inset-0 pointer-events-none z-50">
          {trailPoints.map((point, index) => {
            const age = Date.now() - point.timestamp;
            const opacity = Math.max(0, 1 - age / 1000);
            const scale = 1 - index * 0.05;
            const delay = index * 20;

            return (
              <motion.div
                key={`${point.timestamp}-${index}`}
                className="absolute"
                style={{
                  left: point.x,
                  top: point.y,
                }}
                initial={{ scale: 0, opacity: 0 }}
                animate={{
                  scale: scale,
                  opacity: opacity * 0.8,
                }}
                transition={{
                  delay: delay / 1000,
                  duration: 0.3,
                  ease: "easeOut",
                }}
              >
                <div className="relative">
                  <div
                    className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full"
                    style={{
                      width: 8 + index * 2,
                      height: 8 + index * 2,
                      background: `radial-gradient(circle,
                        hsl(${280 + index * 10}, 100%, 70%) 0%,
                        hsl(${320 + index * 15}, 100%, 60%) 50%,
                        transparent 100%)`,
                      filter: `blur(${index * 0.5}px)`,
                    }}
                  />
                  {index < 5 && (
                    <div
                      className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full animate-ping"
                      style={{
                        width: 12 + index * 3,
                        height: 12 + index * 3,
                        background: `hsl(${190 + index * 20}, 100%, 60%)`,
                        opacity: opacity * 0.3,
                        animationDuration: `${1 + index * 0.2}s`,
                      }}
                    />
                  )}
                </div>
              </motion.div>
            );
          })}

          <motion.div
            className="absolute w-4 h-4 rounded-full"
            animate={{
              x: mousePosition.x - 8,
              y: mousePosition.y - 8,
            }}
            transition={{
              type: "spring",
              stiffness: 800,
              damping: 35,
            }}
          >
            <div className="relative w-full h-full">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-cyan-400 rounded-full animate-pulse" />
              <div
                className="absolute inset-0 bg-white/40 rounded-full animate-ping"
                style={{ animationDuration: "2s" }}
              />
              <div
                className="absolute -inset-2 bg-gradient-to-r from-orange-400/30 to-pink-400/30 rounded-full animate-spin"
                style={{ animationDuration: "3s" }}
              />
            </div>
          </motion.div>
        </div>
      </div>
    </MobileOptimized>
  );
};
