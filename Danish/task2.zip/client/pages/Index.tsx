import { InteractivePortal } from "../components/InteractivePortal";

export default function Index() {
  return <InteractivePortal />;
}
